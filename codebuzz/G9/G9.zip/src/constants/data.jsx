// Currency

export const currencyData = [
    { label: "INR", value: "INR", symbol: "₹" },
    { label: "USD", value: "USD", symbol: "$" },
    { label: "GBP", value: "GBP", symbol: "£" },
    { label: "EUR", value: "EUR", symbol: "€" },
];