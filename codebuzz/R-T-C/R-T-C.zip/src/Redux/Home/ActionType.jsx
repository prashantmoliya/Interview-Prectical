export const REQUEST_USER= "REQUEST_USER";
export const ERROR_USER= "ERROR_USER";

export const GET_USER= "GET_USER";
export const POST_USER= "POST_USER";
export const DELETE_USER= "DELETE_USER";
export const GET_SINGLE_USER= "GET_SINGLE_USER";
export const PUT_USER= "PUT_USER";
